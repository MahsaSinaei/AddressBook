public class BuddyInfo {

    // Instance Variable
    private final String name;

    // Constructor Declaration
    public BuddyInfo (String name) {
        this.name = name;
    }

    // Getter method
    public String getName() {
        return name;
    }

    public static void main(String[] args) {

        BuddyInfo Homer =new BuddyInfo("Homer");
        System.out.println("Hello " + Homer.getName() + "!");
    }
}
