public class AddressBook {

    BuddyInfo Homer =new BuddyInfo("Homer");
    BuddyInfo Ali =new BuddyInfo("Ali");
    BuddyInfo Babak =new BuddyInfo("Babak");
    BuddyInfo Mahsa =new BuddyInfo("Mahsa");

    public void addBuddy(){

    }

    public void  removeBuddy(){

    }
    public static void main(String[] args) {
        BuddyInfo buddy = new BuddyInfo("Jhon");
        AddressBook addressBook = new AddressBook();
    }
}
